import React from "react"
import { Edit } from "react-feather"
  import {
    Button,
    Modal,
    ModalHeader,
    ModalBody,
    ModalFooter,
  } from "reactstrap"

  class ComposeModalGrid extends React.Component {

    state = {
      modal: false
    }

    toggleModal = () => {
      this.setState(prevState => ({
        modal: !prevState.modal
      }))
    }

    render() {
      return (
        <>
          <Button className="btn btn-success ft-1" onClick={this.toggleModal}>
            <Edit  size={16} className="mr-i" />
            COMPOSE
          </Button>
          <Modal
            isOpen={this.state.modal}
            toggle={this.toggleModal}
            className="modal-dialog-centered"
            modal-lg
            fade={false}
          >
            <ModalHeader toggle={this.toggleModal}>
              Vertically Centered
            </ModalHeader>
            <ModalBody className="modal-dialog-centered">
              Candy oat cake topping topping chocolate cake. Icing pudding jelly
              beans I love chocolate carrot cake wafer candy canes. Biscuit
              croissant fruitcake bonbon soufflé.
            </ModalBody>
            <ModalFooter>
              <Button color="primary" onClick={this.toggleModal}>
                Accept
              </Button>{" "}
            </ModalFooter>
          </Modal>
        </>
      );
    }
  }
  export default ComposeModalGrid